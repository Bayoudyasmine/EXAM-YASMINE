package com.example.springexam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringExamApplicationTests {

    @Test
    void contextLoads() {
    }

}
