package com.example.springexam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringExamApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringExamApplication.class, args);
    }
}
